class Bloco_de_carnaval(){
    private int numero_pessoas;
    private String nome_do_bloco;
    private String dono_do_bloco;
    private boolean se_vai_sair;   

    public int getNumero_pessoas(){
        return this.numero_pessoas;
    }

    public String getNome_do_bloco(){
        return this.nome_do_bloco;
    }

    public String getNome_dono(){
        return this.dono_do_bloco;
    }

    public boolean getVai_sair(){
        return this.se_vai_sair;
    }

    public void setNumero_pessoas(int numero_pessoas){
        this.numero_pessoas = 215;
    }

    public void setNome_do_bloco(String Nome_do_bloco){
        this.nome_do_bloco;
    }

    public void setNome_dono(String nome_do_bloco){
        this.dono_do_bloco;
    }

    public void setVai_sair(boolean se_vai_sair){
        this.se_vai_sair;
    }
}

