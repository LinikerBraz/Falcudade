class Cadastro{
    private double id_da_pessoa;
    private String nome_da_pessoa;
    private String nome_da_fantasia;
    
    public double getId_pessoa(){
        return this.id_da_pessoa;
    }

    public String getNome_pessoa(){
        return this.nome_da_pessoa;
    }

    public String getNome_fantasia(){
        return this.nome_da_fantasia;
    }

    public void setId_pessoa(double Id_da_pessoa){
        this.Id_pessoa
    }

    public void setNome_pessoa(String Nome_da_pessoa){
        this.Nome_pessoa;
    }

    public void setNome_fantasia(String nome_da_fantasia){
        this.Nome_fantasia;
    }
}