class Pessoa(){
    private String nome;
    private int idade;
    private double id;
    private boolean maior_idade;

    public String getNome(){
        return this.nome;
    }

    public int getIdade(){
        return this.idade;
    }

    public double getId(){
        return this.id;
    }

    public boolean getMaior_idade(){
        return this.maior_idade;
    }

    public void setNome(String nome){
        this.nome;
    }

    public void setId(double id){
        this.id;
    }

    public void setIdade(int idade){
        this.idade;
    }

    public void setMaior_idade(boolean maior_idade){
        this.maior_idade;
    }
}